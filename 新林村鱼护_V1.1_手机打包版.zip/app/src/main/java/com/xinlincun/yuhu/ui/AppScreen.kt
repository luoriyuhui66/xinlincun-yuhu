
package com.xinlincun.yuhu.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.layout.*

@Composable
fun AppScreen(){
 var page by remember { mutableStateOf(0) }
 Scaffold(
 bottomBar={
  NavigationBar{
   listOf("首页","图鉴","记录","地图","我的").forEachIndexed{ i,t->
    NavigationBarItem(
     selected=page==i,
     onClick={page=i},
     icon={Icon(Icons.Default.Home,null)},
     label={Text(t)}
    )
   }
  }
 }
 ){
  Column(Modifier.padding(it).padding(20.dp)){
   when(page){
    0->Text("新林村鱼护\n我的鱼护 28种鱼")
    1->Text("鱼种图鉴\n已发现鱼类")
    2->Text("记录鱼获\n上传照片")
    3->Text("钓点地图\n新林村河口")
    else->Text("我的\n钓鱼等级")
   }
  }
 }
}
