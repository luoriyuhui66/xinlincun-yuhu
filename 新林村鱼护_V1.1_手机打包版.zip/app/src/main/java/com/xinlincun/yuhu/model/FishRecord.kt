
package com.xinlincun.yuhu.model

data class FishRecord(
 val name:String,
 val weight:String,
 val length:String,
 val location:String
)
