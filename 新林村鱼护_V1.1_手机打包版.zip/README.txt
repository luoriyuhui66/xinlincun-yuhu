新林村鱼护 V1.1 手机打包版

用途：上传到GitHub后使用Actions云端编译APK。
项目：Kotlin + Jetpack Compose
